package com.hybird.final_login_new2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MaintwoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maintwo);
    }
}
